Pagantis (https://www.pagantis.com/ ) module allows your DrupalCommerce
shop to offer financing payments.


Configuration
-------------

This payment module may be added and configured via the normal Rules interface.


Pagantis account settings
------------------------------

Once installed you only have to fill the account details you have in the
https://bo.pagantis.com/users/sing_up
For more information read the Guide.pdf provided with the module.

Troubleshooting
---------------
For any problems, doubts or questions, please contact us at integrations@pagantis.com

Credits
-------
This module is based on a Authorize.net SIM-only implementation.